import inicio_seccion

# Definir un diccionario para almacenar los datos
datos = {}

def inventario_equipos():
    print(".")
#1.
def registrar_prestamo():
    print("Ingrese los datos del prestante")
    nombre = input("Ingrese el nombre: ")
    identificacion = input("Ingrese t.i o c.c: ")
    fecha = input("Ingrese fecha de prestamos: ")
    estado = input("Ingrese estado del prestamo: ")
    datos[identificacion]={"nombre": nombre, "identificacion": identificacion, "fecha": fecha, "estado": estado}
    #print(nombre, identificacion, fecha)
    print("Registro creado con éxito!")

def reporte_por_mes_año():
    print("Leer reportes")
    if len(datos)>0:
        for dict in datos.values():
            print(f"Nombre: {dict["nombre"]}, Identificacion: {dict["identificacion"]}, Fecha: {dict["fecha"]}, Estado: {dict["estado"]}")
    else:
        print("No hay registros")

def actualizar_estado_prestamo():
    print("Actualizar registro")
    identificacion = input("Ingrese la identificacion del registro a actualizar: ")
    if identificacion in datos:
        estado = input("Ingrese (entrego) si es el caso: ")
        datos[identificacion]["estado"]= estado
        print("Registro actualizado con éxito!")
    else:
        print("Registro no encontrado")


def main():
    while True:
        print("\nMenú de opciones:")
        print("1. Crear registro")
        print("2. Leer registros")
        print("3. Actualizar registro")
        print("4. Salir")
        
        opcion = input("Ingrese su opción: ")
        
        if opcion == "1":
            registrar_prestamo()
        elif opcion == "2":
            reporte_por_mes_año()
        elif opcion == "3":
            actualizar_estado_prestamo()
        elif opcion == "4":
            print("Hasta luego!")
            break
        else:
            print("Opción no válida. Intente de nuevo.")

# Llamar a la función principal
main()