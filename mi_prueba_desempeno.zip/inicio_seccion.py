
#aqui estamos definiendo el usuario y contraseña establecidos para el administrador
usuario_por_defecto = "admin.time"
contraseña_por_defecto = "1234"

#aca le estamos definiendo una funcion como inicio de seccion para que el usuario sepa que paso debe tomar.
def inicio_seccion():
    print("---INICIO SECCION---")
    #vamos a pedir el nombre del usuario
    usuario = input("Ingrese el usuario: ")
    print(usuario)
    #pedimos la contraseña
    contraseña = input("Ingresar la contraseña: ")
    print(contraseña)
    #aca hacemos un si el usuario que se ingresa en el imput es igual al usuario definido (usuario_por_defecto)
    if usuario != usuario_por_defecto:
        print("El nombre de usuario es incorrecto")
        return False
    #aca hacemos un si la contraseña que se ingresa en el imput es igual a contraseña establecida (contraseña_por_defecto)
    elif contraseña == contraseña_por_defecto:
        print("---!Se inicio seccion ADMIN¡---")
        return True
    else:
        print("Contraseña incorrecta")
        return False
#aqui estamos haciento una funcion mientras sea verdad que la variable inicio_seccion sea la establecida me corra y pare en el break. si no que me imprima el intentar de nuevo. hasta que se ejecute bien 
def main():
    while True:
        variable = inicio_seccion()
        if variable == True:
            break
        opcion = input("Intentar de nuevo  (si/no): ")
        if opcion.lower() != "si":
            print("hasta luego")
            break

main()
